/**
 * Phone floating button.
 *
 * Handles the configurable appear delay and entrance animation.
 *
 * On desktop (>= 750px) with data-desktop-popup="true", clicking the button
 * opens a contact card instead of dialing directly, and the round button turns
 * into a close (X). Clicking the X, clicking outside, or pressing Escape closes
 * the card and brings the phone button back.
 *
 * On mobile the button keeps its native tel: behaviour (tap to call).
 */
class PhoneButton extends HTMLElement {
  connectedCallback() {
    const delay = parseFloat(this.dataset.delay || '0') * 1000;
    if (delay > 0) {
      setTimeout(() => this.classList.add('is-visible'), delay);
    } else {
      // Reveal on the next frame so the entrance transition still plays.
      requestAnimationFrame(() => this.classList.add('is-visible'));
    }

    this.btn = this.querySelector('.tel-float__btn');
    this.desktopPopup = this.dataset.desktopPopup === 'true';
    if (!this.btn) return;

    this.btn.addEventListener('click', (event) => {
      if (this.desktopPopup && this.isDesktop()) {
        event.preventDefault();
        this.toggle();
      }
      // Otherwise let the native tel: link dial (mobile).
    });

    // Close when clicking anywhere outside the component.
    document.addEventListener('click', (event) => {
      if (this.classList.contains('is-open') && !this.contains(event.target)) {
        this.close();
      }
    });

    // Close on Escape.
    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') this.close();
    });
  }

  isDesktop() {
    return window.matchMedia('(min-width: 750px)').matches;
  }

  toggle() {
    this.classList.toggle('is-open');
  }

  close() {
    this.classList.remove('is-open');
  }
}

if (!customElements.get('phone-button')) {
  customElements.define('phone-button', PhoneButton);
}
