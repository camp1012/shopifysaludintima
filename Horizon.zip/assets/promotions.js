/**
 * Promotions engine: simulates compare_at_price display for automatic/coupon
 * discounts configured through the `promotions` section. Pure client-side
 * rewrite of price markup + badge injection. The real discount is still
 * applied by Shopify checkout — this only recovers the visual "on sale" cue.
 *
 * Locale/currency strategy: instead of re-formatting a raw cents value with a
 * money-format template (which would be wrong when the customer browses in a
 * currency other than the shop's base), we read the already-rendered price
 * text from the DOM, derive the separator pattern from it, scale the numeric
 * portion, and reinject — preserving the display currency, separators, and
 * any inner markup like <span class="money">.
 */

const PRICE_ROOT_SELECTOR = '[data-promo-price-root]';
const BADGE_SLOT_SELECTOR = '[data-promo-badge-slot]';
const MEDIA_BADGE_SELECTOR = '[data-promo-media-badge-slot]';
const GALLERY_BADGE_SELECTOR = '[data-promo-gallery-badge-slot]';
const APPLIED_CLASS = 'promo-applied';
const BADGE_MARKER = 'data-promo-badge';
// Marks badges whose percentage was force-rewritten (sum of native + promo)
// so the MutationObserver never sums twice.
const FORCE_MARKER = 'data-promo-forced';
// Ancestor selectors that identify a product card root. When no ancestor
// matches (e.g. PDP main price), the card highlight is skipped.
const CARD_SELECTOR = [
  'product-card',
  '.product__card--list',
  '.product__card',
  '.product-grid-item',
  '.deals--product__card',
  '.resource-card',
  '.lookbook__shop--product',
  '.gallery-product-card',
  '.product-card-featured',
].join(', ');
// Within a card, find the image/thumbnail wrapper to attach the highlight to.
const IMAGE_WRAPPER_SELECTOR = [
  '.product-media',
  '.product__card-list__thumbnail',
  '.product__media_thumbnail',
  '.product-card__image',
  '.product-card__media',
  '.card-gallery',
  '.product__card-thumbnail',
  '.product-card-featured__media',
].join(', ');
const HIGHLIGHT_CLASS = 'promo-card--highlighted';
const COUNTDOWN_CLASS = 'promo-countdown';
const COUNTDOWN_MARKER = 'data-promo-countdown';

function buildEntry(el) {
  return {
    type: el.dataset.discountType === 'fixed' ? 'fixed' : 'percentage',
    value: parseFloat(el.dataset.discountValue) || 0,
    displayPercentage: parseInt(el.dataset.displayPercentage, 10) || 0,
    overrideExistingSale: el.dataset.overrideExistingSale === 'true',
    forcePercentage: el.dataset.forcePercentage === 'true',
    colorBackground: el.dataset.colorBackground || '',
    colorText: el.dataset.colorText || '',
    badgeLabel: el.dataset.badgeLabel || '',
    cardBorderEnabled: el.dataset.cardBorderEnabled === 'true',
    cardBorderColor: el.dataset.cardBorderColor || '',
    cardBorderWidth: parseInt(el.dataset.cardBorderWidth, 10) || 2,
    countdownEnabled: el.dataset.countdownEnabled === 'true',
    countdownEndAt: parseCountdownDate(el.dataset.countdownEnd || ''),
    countdownLabel: el.dataset.countdownLabel || '',
  };
}

/**
 * Two kinds of entries coexist:
 *  - map:       productId -> promo (explicit include lists)
 *  - wildcards: promos with excludedIds — apply to EVERY product whose id is
 *               NOT in the set. First matching wildcard wins.
 * Explicit entries always take precedence over wildcards.
 */
function parseEntries(root) {
  const map = new Map();
  const wildcards = [];
  root.querySelectorAll('.promotion-entry').forEach((el) => {
    if (el.dataset.excludeMode === 'true') {
      const entry = buildEntry(el);
      entry.excludedIds = new Set(
        (el.dataset.excludedIds || '')
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean)
      );
      wildcards.push(entry);
      return;
    }
    const id = el.dataset.productId;
    if (!id) return;
    map.set(id, buildEntry(el));
  });
  return { map, wildcards };
}

/**
 * Extract the first percentage number from a badge's text ("-10%" -> 10).
 * Returns 0 when no percentage is present.
 */
function parsePercentFromText(text) {
  const match = (text || '').match(/(\d+(?:[.,]\d+)?)\s*%/);
  if (!match) return 0;
  return Math.round(parseFloat(match[1].replace(',', '.')));
}

/**
 * Parse a localized money string. Returns info about separators and value, or
 * null if no number found. Heuristics:
 *  - If multiple distinct separator chars appear, the LAST one is decimal.
 *  - If a single kind appears once with 1–2 trailing digits, treat as decimal.
 *  - Else all separators are thousands and precision is 0.
 */
function parseMoneyString(text) {
  if (!text) return null;
  const match = text.match(/\d[\d.,\s'\u00A0]*\d|\d/);
  if (!match) return null;
  const numStr = match[0];

  const sepMatches = [...numStr.matchAll(/[.,\s'\u00A0]/g)];
  if (sepMatches.length === 0) {
    const major = parseInt(numStr, 10);
    return {
      numStr,
      thousandsSep: '',
      decimalSep: '',
      precision: 0,
      major,
      minor: major,
    };
  }

  const sepCounts = {};
  for (const m of sepMatches) sepCounts[m[0]] = (sepCounts[m[0]] || 0) + 1;
  const uniqueSeps = Object.keys(sepCounts);
  const lastSep = sepMatches[sepMatches.length - 1];
  const lastSepChar = lastSep[0];
  const digitsAfterLast = numStr.length - lastSep.index - 1;

  let decimalSep = '';
  let thousandsSep = '';
  let precision = 0;

  if (uniqueSeps.length > 1) {
    decimalSep = lastSepChar;
    precision = digitsAfterLast;
    thousandsSep = uniqueSeps.find((s) => s !== decimalSep) || '';
  } else if (sepCounts[lastSepChar] === 1 && digitsAfterLast >= 1 && digitsAfterLast <= 2) {
    decimalSep = lastSepChar;
    precision = digitsAfterLast;
  } else {
    thousandsSep = lastSepChar;
  }

  let cleaned = numStr;
  if (thousandsSep) cleaned = cleaned.split(thousandsSep).join('');
  if (decimalSep && decimalSep !== '.') cleaned = cleaned.replace(decimalSep, '.');
  const major = parseFloat(cleaned);
  if (Number.isNaN(major)) return null;
  const minor = Math.round(major * Math.pow(10, precision));

  return { numStr, thousandsSep, decimalSep, precision, major, minor };
}

function formatMoneyInPattern(newMinor, info) {
  const newMajor = newMinor / Math.pow(10, info.precision);
  const rounded = newMajor.toFixed(info.precision);
  const [whole, frac] = rounded.split('.');
  let wholeFormatted = whole;
  if (info.thousandsSep) {
    wholeFormatted = whole.replace(/\B(?=(\d{3})+(?!\d))/g, info.thousandsSep);
  }
  if (info.precision > 0 && frac) {
    return `${wholeFormatted}${info.decimalSep || '.'}${frac}`;
  }
  return wholeFormatted;
}

function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Accept admin-friendly date strings: "YYYY-MM-DD HH:MM[:SS]" or full ISO 8601.
 * Returns a millisecond timestamp or null when unparseable / in the past.
 * The space form is normalized to ISO so both Safari and Firefox parse it.
 */
function parseCountdownDate(raw) {
  if (!raw) return null;
  const trimmed = raw.trim();
  if (!trimmed) return null;
  const normalized = /^\d{4}-\d{2}-\d{2}[ T]\d{2}:\d{2}(:\d{2})?$/.test(trimmed)
    ? trimmed.replace(' ', 'T')
    : trimmed;
  const ts = Date.parse(normalized);
  if (Number.isNaN(ts)) return null;
  return ts;
}

function formatCountdown(remainingMs) {
  if (remainingMs <= 0) return null;
  const totalSec = Math.floor(remainingMs / 1000);
  const days = Math.floor(totalSec / 86400);
  const hours = Math.floor((totalSec % 86400) / 3600);
  const minutes = Math.floor((totalSec % 3600) / 60);
  const seconds = totalSec % 60;
  const pad = (n) => String(n).padStart(2, '0');
  if (days > 0) return `${days}d ${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
}

function replaceFirstNumberInHTML(html, oldNumStr, newNumStr) {
  // Anchor replacement with non-digit boundary on the right so we don't also
  // match a prefix of a longer number elsewhere in the markup.
  const pattern = new RegExp(`${escapeRegex(oldNumStr)}(?!\\d)`);
  return html.replace(pattern, newNumStr);
}

class PromotionsEngine {
  constructor() {
    const root = document.getElementById('promotions-data');
    if (!root) return;

    const parsed = parseEntries(root);
    this.map = parsed.map;
    this.wildcards = parsed.wildcards;
    if (this.map.size === 0 && this.wildcards.length === 0) return;

    this.badgeScheme = root.dataset.badgeScheme || 'scheme-1';
    this.saleText = root.dataset.saleText || '';
    this.saleLabel = root.dataset.saleLabel || this.saleText || 'Sale';
    this.showPercentage = root.dataset.showPercentage === 'true';

    this.applyingLocks = new WeakSet();

    this.applyAll();
    this.listen();
  }

  getPromo(productId) {
    if (!productId) return null;
    const id = String(productId);
    // Explicit include entries take precedence over wildcards.
    const explicit = this.map.get(id);
    if (explicit) return explicit;
    // Exclude-mode wildcards: applies unless the id is in the excluded set.
    for (const wildcard of this.wildcards) {
      if (!wildcard.excludedIds.has(id)) return wildcard;
    }
    return null;
  }

  /**
   * Compute the discount ratio (0..1) in BASE currency terms. The ratio is
   * applied to the DISPLAY-currency amount read from the DOM — so percentage
   * discounts translate cleanly, and fixed discounts are approximated by
   * their base-currency equivalent ratio.
   */
  computeSaleRatio(promo, baseMinor) {
    if (promo.type === 'percentage') {
      const pct = Math.max(0, Math.min(100, promo.value));
      return pct / 100;
    }
    const fixedBaseMinor = Math.round(promo.value * 100);
    if (!baseMinor || baseMinor <= 0) return 0;
    return Math.min(1, fixedBaseMinor / baseMinor);
  }

  percentageForBadge(promo) {
    if (promo.type === 'percentage') return Math.round(promo.value);
    return promo.displayPercentage || 0;
  }

  /**
   * Force mode: rewrite an existing badge's percentage as the SUM of the
   * percentage it already shows plus the promo's percentage (e.g. a native
   * -10% badge with a 25% promo becomes -35%). Marks the badge so observer
   * re-fires never sum twice. Returns true when a rewrite happened.
   */
  forceSumBadge(badgeEl, textTarget, promo) {
    if (badgeEl.hasAttribute(FORCE_MARKER)) return true;
    const promoPct = this.percentageForBadge(promo);
    if (promoPct <= 0) return false;
    const existingPct = parsePercentFromText(textTarget.textContent);
    const totalPct = existingPct + promoPct;
    textTarget.textContent = `-${totalPct}%`;
    if (promo.colorBackground) badgeEl.style.background = promo.colorBackground;
    if (promo.colorText) badgeEl.style.color = promo.colorText;
    badgeEl.setAttribute(FORCE_MARKER, '');
    return true;
  }

  applyAll(scope = document) {
    scope.querySelectorAll(PRICE_ROOT_SELECTOR).forEach((el) => this.applyPrice(el));
    scope.querySelectorAll(BADGE_SLOT_SELECTOR).forEach((el) => this.applyBadge(el));
    scope.querySelectorAll(MEDIA_BADGE_SELECTOR).forEach((el) => this.applyMediaBadge(el));
    scope.querySelectorAll(GALLERY_BADGE_SELECTOR).forEach((el) => this.applyGalleryBadge(el));
  }

  applyPrice(el) {
    if (this.applyingLocks.has(el)) return;
    const promo = this.getPromo(el.dataset.productId);
    if (!promo) return;
    if (el.dataset.hasVolumePricing === 'true') return;
    // When the PDM subscription widget is active on this product, the
    // dedicated module owns pricing display (subscription + onetime cards
    // already render their own compare/sale visuals). Skipping here keeps
    // the PDP main price block from competing with Horizon's native
    // selling_plan rendering when a subscription is selected.
    if (el.closest('.pdm-active')) return;

    const baseMinor = parseInt(el.dataset.variantPrice, 10);
    if (!baseMinor || Number.isNaN(baseMinor)) return;

    const existingCompare = parseInt(el.dataset.variantComparePrice, 10) || 0;
    if (existingCompare > baseMinor && !promo.overrideExistingSale) return;

    const ratio = this.computeSaleRatio(promo, baseMinor);
    if (ratio <= 0 || ratio >= 1) return;

    const regular = el.querySelector(':scope > .price__regular');
    const sale = el.querySelector(':scope > .price__sale');
    if (!regular || !sale) return;

    const originalPriceEl = regular.querySelector('.price');
    if (!originalPriceEl) return;
    const originalHTML = originalPriceEl.innerHTML;
    const originalText = originalPriceEl.textContent || '';

    const info = parseMoneyString(originalText);
    if (!info) return;

    const saleMinor = Math.round(info.minor * (1 - ratio));
    if (saleMinor >= info.minor || saleMinor < 0) return;

    const newNumStr = formatMoneyInPattern(saleMinor, info);
    const saleHTML = replaceFirstNumberInHTML(originalHTML, info.numStr, newNumStr);

    this.applyingLocks.add(el);
    try {
      regular.classList.add('price__hidden');
      sale.classList.remove('price__hidden');
      const compareSpan = sale.querySelector('.compare-at-price');
      const saleSpan = sale.querySelector('.price-item--sale.price');
      if (compareSpan) compareSpan.innerHTML = originalHTML;
      if (saleSpan) saleSpan.innerHTML = saleHTML;

      const discountPill = sale.querySelector('[data-price-discount-pill]');
      if (discountPill) {
        const displayPct = Math.round((1 - saleMinor / info.minor) * 100);
        if (displayPct > 0) {
          discountPill.textContent = `-${displayPct}%`;
          if (promo.colorBackground) discountPill.style.background = promo.colorBackground;
          if (promo.colorText) discountPill.style.color = promo.colorText;
          discountPill.removeAttribute('hidden');
        }
      }

      el.classList.add(APPLIED_CLASS);
      el.dataset.promoApplied = 'true';

      this.applyCardBorder(el, promo);
      this.applyCardCountdown(el, promo);
    } finally {
      queueMicrotask(() => this.applyingLocks.delete(el));
    }
  }

  revertPrice(el) {
    // Toggle visibility back to the native state. innerHTML mutations in
    // applyPrice live inside the hidden .price__sale block, so simply
    // restoring the original visibility flags is enough.
    const regular = el.querySelector(':scope > .price__regular');
    const sale = el.querySelector(':scope > .price__sale');
    if (regular) regular.classList.remove('price__hidden');
    if (sale) sale.classList.add('price__hidden');
    el.classList.remove(APPLIED_CLASS);
    delete el.dataset.promoApplied;
  }

  applyCardBorder(priceEl, promo) {
    if (!promo.cardBorderEnabled || !promo.cardBorderColor) return;
    const card = priceEl.closest(CARD_SELECTOR);
    if (!card) return;
    // Target the image wrapper inside the card so the border frames the
    // image only and inherits the image's existing border-radius.
    const target = card.querySelector(IMAGE_WRAPPER_SELECTOR) || card;
    if (target.classList.contains(HIGHLIGHT_CLASS)) return;
    target.style.setProperty('--promo-border-color', promo.cardBorderColor);
    target.style.setProperty('--promo-border-width', `${promo.cardBorderWidth}px`);
    target.classList.add(HIGHLIGHT_CLASS);
  }

  applyCardCountdown(priceEl, promo) {
    if (!promo.countdownEnabled || !promo.countdownEndAt) return;
    if (promo.countdownEndAt - Date.now() <= 0) return;
    const card = priceEl.closest(CARD_SELECTOR);
    if (!card) return;
    const target = card.querySelector(IMAGE_WRAPPER_SELECTOR) || card;
    if (target.querySelector(`[${COUNTDOWN_MARKER}]`)) return;

    const color = promo.cardBorderColor || promo.colorBackground || '';
    const el = document.createElement('span');
    el.className = COUNTDOWN_CLASS;
    el.setAttribute(COUNTDOWN_MARKER, '');
    el.dataset.endsAt = String(promo.countdownEndAt);
    if (color) el.style.setProperty('--promo-countdown-color', color);

    if (promo.countdownLabel) {
      const label = document.createElement('span');
      label.className = 'promo-countdown__label';
      label.textContent = promo.countdownLabel;
      el.appendChild(label);
    }
    const time = document.createElement('span');
    time.className = 'promo-countdown__time';
    time.textContent = formatCountdown(promo.countdownEndAt - Date.now()) || '';
    el.appendChild(time);

    // The image wrapper might not be positioned; promo-card--countdown adds
    // position:relative so absolute positioning of the pill works even when
    // the border highlight is disabled.
    target.classList.add('promo-card--countdown');
    target.appendChild(el);
    this.ensureCountdownTicker();
  }

  ensureCountdownTicker() {
    if (this.countdownTicker) return;
    const tick = () => {
      const nodes = document.querySelectorAll(`.${COUNTDOWN_CLASS}`);
      if (nodes.length === 0) return;
      const now = Date.now();
      nodes.forEach((node) => {
        const endsAt = parseInt(node.dataset.endsAt, 10);
        if (!endsAt) return;
        const remaining = endsAt - now;
        const formatted = formatCountdown(remaining);
        if (formatted === null) {
          node.remove();
          return;
        }
        const timeEl = node.querySelector('.promo-countdown__time');
        if (timeEl && timeEl.textContent !== formatted) timeEl.textContent = formatted;
      });
    };
    this.countdownTicker = setInterval(tick, 1000);
  }

  applyBadge(el) {
    const promo = this.getPromo(el.dataset.productId);
    if (!promo) return;
    if (el.querySelector(`[${BADGE_MARKER}]`)) return;

    const nativePctEl = el.querySelector('.sale__save--percent');
    const hasNativeSaleBadge = el.querySelector('.sale__save--percent, .sale__text');

    // Force mode: sum native percentage + promo percentage and rewrite.
    if (hasNativeSaleBadge && promo.forcePercentage && nativePctEl) {
      const nativeBadge = nativePctEl.closest('.badge') || nativePctEl;
      if (this.forceSumBadge(nativeBadge, nativePctEl, promo)) return;
    }

    if (hasNativeSaleBadge && !promo.overrideExistingSale && !promo.forcePercentage) return;
    if (hasNativeSaleBadge && promo.overrideExistingSale && !promo.forcePercentage) {
      el.querySelectorAll('.badge').forEach((badge) => {
        if (badge.querySelector('.sale__save--percent, .sale__text')) badge.remove();
      });
    }

    const pct = this.percentageForBadge(promo);
    const badge = document.createElement('span');
    badge.className = `badge badge--bottom-left color-${this.badgeScheme}`;
    badge.setAttribute(BADGE_MARKER, '');
    badge.setAttribute('aria-hidden', 'true');
    if (promo.colorBackground) badge.style.background = promo.colorBackground;
    if (promo.colorText) badge.style.color = promo.colorText;

    if ((this.showPercentage || promo.type === 'fixed' || promo.forcePercentage) && pct > 0) {
      const pctSpan = document.createElement('span');
      pctSpan.className = 'sale__save--percent';
      pctSpan.textContent = `-${pct}%`;
      badge.appendChild(pctSpan);
    }
    const text = promo.badgeLabel || this.saleText;
    if (text) {
      const textSpan = document.createElement('span');
      textSpan.className = 'sale__text';
      textSpan.textContent = text;
      badge.appendChild(textSpan);
    }
    el.appendChild(badge);
  }

  applyMediaBadge(el) {
    const promo = this.getPromo(el.dataset.productId);
    if (!promo) return;
    if (el.querySelector(`[${BADGE_MARKER}]`)) return;

    const existingBadge = el.querySelector('.product-badge');

    // Force mode: existing badge -> rewrite with the SUM of both percentages.
    if (existingBadge && promo.forcePercentage) {
      this.forceSumBadge(existingBadge, existingBadge, promo);
      return;
    }

    if (existingBadge) return;

    const pct = this.percentageForBadge(promo);
    if (pct <= 0) return;

    const badge = document.createElement('div');
    badge.className = 'product-badge';
    badge.setAttribute(BADGE_MARKER, '');
    badge.textContent = `-${pct}%`;
    if (promo.colorBackground) badge.style.background = promo.colorBackground;
    if (promo.colorText) badge.style.color = promo.colorText;
    el.appendChild(badge);
  }

  applyGalleryBadge(el) {
    const promo = this.getPromo(el.dataset.productId);
    if (!promo) return;
    if (el.querySelector(`[${BADGE_MARKER}]`)) return;

    const existingBadge = el.querySelector('.product-badges__badge');

    // Force mode: if the existing gallery badge shows a percentage, sum and
    // rewrite it; if it shows a text label, leave it as is.
    if (existingBadge && promo.forcePercentage) {
      if (parsePercentFromText(existingBadge.textContent) > 0) {
        this.forceSumBadge(existingBadge, existingBadge, promo);
      }
      return;
    }

    if (existingBadge) return;

    const scheme = el.dataset.saleScheme || this.badgeScheme;
    const badge = document.createElement('div');
    badge.className = `product-badges__badge product-badges__badge--rectangle color-${scheme}`;
    badge.setAttribute(BADGE_MARKER, '');
    badge.textContent = promo.badgeLabel || this.saleLabel;
    if (promo.colorBackground) badge.style.background = promo.colorBackground;
    if (promo.colorText) badge.style.color = promo.colorText;
    el.appendChild(badge);
  }

  listen() {
    document.addEventListener('variant:update', (event) => {
      const container = event.target instanceof Element ? event.target.closest('.shopify-section, dialog') : null;
      const scope = container || document;
      requestAnimationFrame(() => this.applyAll(scope));
    });

    // PDM widget initializes async after LOOP_WIDGET. When it marks the
    // product info wrapper as pdm-active it dispatches this event so we
    // revert any price markup we may have already injected on first load.
    document.addEventListener('promotions:revert-pdp', (event) => {
      const container = event.target instanceof Element ? event.target : document;
      container.querySelectorAll(PRICE_ROOT_SELECTOR).forEach((el) => this.revertPrice(el));
    });

    const mutationObserver = new MutationObserver((mutations) => {
      for (const mutation of mutations) {
        for (const node of mutation.addedNodes) {
          if (!(node instanceof Element)) continue;
          if (node.matches?.(PRICE_ROOT_SELECTOR)) this.applyPrice(node);
          node.querySelectorAll?.(PRICE_ROOT_SELECTOR).forEach((el) => this.applyPrice(el));
          if (node.matches?.(BADGE_SLOT_SELECTOR)) this.applyBadge(node);
          node.querySelectorAll?.(BADGE_SLOT_SELECTOR).forEach((el) => this.applyBadge(el));
          if (node.matches?.(MEDIA_BADGE_SELECTOR)) this.applyMediaBadge(node);
          node.querySelectorAll?.(MEDIA_BADGE_SELECTOR).forEach((el) => this.applyMediaBadge(el));
          if (node.matches?.(GALLERY_BADGE_SELECTOR)) this.applyGalleryBadge(node);
          node.querySelectorAll?.(GALLERY_BADGE_SELECTOR).forEach((el) => this.applyGalleryBadge(el));
        }
      }
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });
  }
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => new PromotionsEngine());
} else {
  new PromotionsEngine();
}