class FloatingShare extends HTMLElement {
  connectedCallback() {
    this.toggleBtn = this.querySelector('[data-share-toggle]');
    this.panel = this.querySelector('[data-share-panel]');
    this.toast = this.querySelector('[data-share-toast]');
    this.shareUrl = this.dataset.url || window.location.href;
    this.shareTitle = this.dataset.title || document.title;

    this.toggleBtn?.addEventListener('click', (event) => {
      event.stopPropagation();
      this.toggle();
    });

    this.querySelectorAll('[data-share-action]').forEach((el) => {
      el.addEventListener('click', (event) => this.handleAction(event));
    });

    this.querySelectorAll('[data-share-link]').forEach((el) => {
      el.addEventListener('click', () => {
        setTimeout(() => this.close(), 60);
      });
    });

    document.addEventListener('click', (event) => {
      if (!this.contains(event.target)) this.close();
    });

    document.addEventListener('keydown', (event) => {
      if (event.key === 'Escape') this.close();
    });

    if (navigator.share) this.classList.add('has-native-share');
    this.initVisibility();
  }

  initVisibility() {
    let lastY = window.scrollY;
    let idleTimer = null;
    const threshold = 280;

    const update = () => {
      const y = window.scrollY;
      const past = y > threshold;
      const nearBottom = window.innerHeight + y >= document.documentElement.scrollHeight - 120;

      this.classList.toggle('is-revealed', past && !nearBottom);

      const dy = y - lastY;
      if (past) {
        if (dy > 6) this.classList.add('is-dim');
        else if (dy < -6) this.classList.remove('is-dim');
        clearTimeout(idleTimer);
        idleTimer = setTimeout(() => this.classList.remove('is-dim'), 700);
      }
      lastY = y;
    };

    update();
    window.addEventListener('scroll', update, { passive: true });
    window.addEventListener('resize', update, { passive: true });
  }

  toggle() {
    this.classList.contains('is-open') ? this.close() : this.open();
  }

  open() {
    this.classList.add('is-open');
    this.toggleBtn?.setAttribute('aria-expanded', 'true');
  }

  close() {
    this.classList.remove('is-open');
    this.toggleBtn?.setAttribute('aria-expanded', 'false');
  }

  showToast(message) {
    if (!this.toast) return;
    this.toast.textContent = message;
    this.toast.classList.add('is-visible');
    clearTimeout(this._toastTimer);
    this._toastTimer = setTimeout(() => {
      this.toast.classList.remove('is-visible');
    }, 2200);
  }

  async copy(message) {
    try {
      await navigator.clipboard.writeText(this.shareUrl);
      this.showToast(message);
      return true;
    } catch (_err) {
      this.showToast('No se pudo copiar el enlace');
      return false;
    }
  }

  isMobile() {
    return /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent);
  }

  async tryNativeShare(fallbackToastOnCopy) {
    if (navigator.share) {
      try {
        await navigator.share({ title: this.shareTitle, url: this.shareUrl });
        return true;
      } catch (_err) {
        return false;
      }
    }
    await this.copy(fallbackToastOnCopy);
    return false;
  }

  async handleAction(event) {
    const el = event.currentTarget;
    const action = el.dataset.shareAction;

    switch (action) {
      case 'copy':
        await this.copy('Enlace copiado');
        break;
      case 'instagram':
        await this.tryNativeShare('Enlace copiado · pégalo en Instagram');
        break;
      case 'tiktok':
        await this.tryNativeShare('Enlace copiado · pégalo en TikTok');
        break;
      case 'messenger':
        if (this.isMobile()) {
          window.location.href = `fb-messenger://share/?link=${encodeURIComponent(this.shareUrl)}`;
        } else {
          this.copy('Enlace copiado · pégalo en Messenger');
          window.open('https://www.messenger.com/', '_blank', 'noopener');
        }
        break;
      case 'native':
        if (navigator.share) {
          try {
            await navigator.share({ title: this.shareTitle, url: this.shareUrl });
          } catch (_err) {}
        }
        break;
    }
    this.close();
  }
}

if (!customElements.get('floating-share')) {
  customElements.define('floating-share', FloatingShare);
}
