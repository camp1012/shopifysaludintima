/**
 * WhatsApp floating button.
 *
 * Builds the final wa.me link at click time so it can include the page the
 * customer is on (data-append-url) and any UTM parameters present in the URL
 * (data-read-utms). Handles a configurable appear delay.
 */
class WhatsAppButton extends HTMLElement {
  connectedCallback() {
    this.link = this.querySelector('.wa-float__btn');
    if (!this.link) return;

    const delay = parseFloat(this.dataset.delay || '0') * 1000;
    if (delay > 0) {
      setTimeout(() => this.classList.add('is-visible'), delay);
    } else {
      // Reveal on the next frame so the entrance transition still plays.
      requestAnimationFrame(() => this.classList.add('is-visible'));
    }

    this.link.addEventListener('click', (event) => {
      event.preventDefault();
      window.open(this.buildUrl(), '_blank', 'noopener,noreferrer');
    });
  }

  buildUrl() {
    const phone = (this.dataset.phone || '').replace(/\D/g, '');
    const parts = [];

    const baseMessage = (this.dataset.message || '').trim();
    if (baseMessage) parts.push(baseMessage);

    if (this.dataset.appendUrl === 'true') {
      parts.push(`Página: ${window.location.href}`);
    }

    if (this.dataset.readUtms === 'true') {
      const utms = this.readUtms();
      if (utms) parts.push(utms);
    }

    const text = encodeURIComponent(parts.join('\n\n'));
    const base = `https://wa.me/${phone}`;
    return text ? `${base}?text=${text}` : base;
  }

  readUtms() {
    const params = new URLSearchParams(window.location.search);
    const keys = [
      'utm_source',
      'utm_medium',
      'utm_campaign',
      'utm_term',
      'utm_content',
    ];
    const found = keys
      .filter((key) => params.get(key))
      .map((key) => `${key}: ${params.get(key)}`);
    return found.length ? found.join('\n') : '';
  }
}

if (!customElements.get('whatsapp-button')) {
  customElements.define('whatsapp-button', WhatsAppButton);
}
