import { sectionRenderer } from '@theme/section-renderer';

/**
 * Fetches the blog articles that match the current search term, scoped to
 * articles only, and interleaves them into the top of the search results grid.
 *
 * Why this exists: Shopify returns a maximum of 50 search.results and groups all
 * products before any articles. On broad searches the products fill that window,
 * so the blog posts get pushed out and barely show. Requesting the same section
 * with `type=article` (via the Section Rendering API) returns up to 50 matching
 * articles regardless of how many products matched, which we then place from the
 * top of the grid. The server-rendered (capped) articles act as a no-JS fallback
 * and are replaced here to avoid duplicates.
 */
class SearchArticles extends HTMLElement {
  connectedCallback() {
    // Only enhance the first page of results — articles belong at the top.
    const currentPage = new URL(location.href).searchParams.get('page');
    if (currentPage && currentPage !== '1') return;

    requestAnimationFrame(() => {
      this.#injectArticles().catch(() => {
        /* Leave the server-rendered fallback in place on any failure. */
      });
    });
  }

  async #injectArticles() {
    const sectionId = this.getAttribute('section-id');
    const terms = this.getAttribute('search-terms');
    if (!sectionId || !terms) return;

    const grid = this.closest('results-list')?.querySelector('[ref="grid"]');
    if (!grid) return;

    const url = new URL(Theme.routes.search_url, location.origin);
    url.searchParams.set('q', terms);
    url.searchParams.set('type', 'article');

    const html = await sectionRenderer.getSectionHTML(sectionId, true, url);
    if (!html) return;

    const doc = new DOMParser().parseFromString(html, 'text/html');
    const articles = Array.from(doc.querySelectorAll('li.product-grid__item--article'));
    if (articles.length === 0) return;

    // Drop the pagination hooks so the infinite-scroll logic only ever counts
    // the product cards, never these injected articles.
    for (const article of articles) {
      article.removeAttribute('ref');
      article.removeAttribute('data-page');
    }

    // Remove the capped server-rendered articles to avoid duplicates.
    for (const existing of grid.querySelectorAll('li.product-grid__item--article')) {
      existing.remove();
    }

    const products = Array.from(grid.children).filter(
      (el) =>
        el.classList.contains('product-grid__item') && !el.classList.contains('product-grid__item--article')
    );

    if (products.length === 0) {
      grid.append(...articles);
      return;
    }

    // Spread the articles evenly across the products, starting at the top.
    const interval = Math.max(1, Math.floor(products.length / articles.length));

    let placed = 0;
    for (let i = 0; i < products.length && placed < articles.length; i += interval) {
      grid.insertBefore(articles[placed], products[i]);
      placed += 1;
    }

    // Append any articles that didn't get an interval slot (more articles than products).
    for (; placed < articles.length; placed += 1) {
      grid.append(articles[placed]);
    }
  }
}

if (!customElements.get('search-articles')) {
  customElements.define('search-articles', SearchArticles);
}
