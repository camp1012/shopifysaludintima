(function () {
  const REVIEWS_SELECTOR = '.jdgm-rev-widg, #judgeme_product_reviews, [data-widget-name="review_widget"]';

  function scrollToReviews(event) {
    const target = document.querySelector(REVIEWS_SELECTOR);
    if (!target) return;
    if (event) event.preventDefault();
    const headerOffset = 80;
    const top = target.getBoundingClientRect().top + window.pageYOffset - headerOffset;
    window.scrollTo({ top, behavior: 'smooth' });
  }

  function bindBadge(badge) {
    if (!badge || badge.dataset.scrollBound === '1') return;
    badge.dataset.scrollBound = '1';

    if (badge.style.display === 'none') badge.style.display = '';

    badge.style.cursor = 'pointer';
    if (!badge.hasAttribute('role')) badge.setAttribute('role', 'button');
    if (!badge.hasAttribute('tabindex')) badge.setAttribute('tabindex', '0');
    if (!badge.hasAttribute('aria-label')) {
      badge.setAttribute('aria-label', 'Ver reseñas');
    }

    badge.addEventListener('click', scrollToReviews);
    badge.addEventListener('keydown', (event) => {
      if (event.key === 'Enter' || event.key === ' ') scrollToReviews(event);
    });
  }

  function scan() {
    document.querySelectorAll('.jdgm-prev-badge').forEach(bindBadge);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', scan);
  } else {
    scan();
  }

  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      for (const node of mutation.addedNodes) {
        if (!(node instanceof Element)) continue;
        if (node.matches?.('.jdgm-prev-badge')) bindBadge(node);
        node.querySelectorAll?.('.jdgm-prev-badge').forEach(bindBadge);
      }
    }
  });

  observer.observe(document.documentElement, { childList: true, subtree: true });
})();
